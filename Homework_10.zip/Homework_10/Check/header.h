#ifndef HEADER_FILE
#define HEADER_FILE

int face0(int l0, int l1, int l2, int nPROC0);
int face1(int l0, int l1, int l2, int nPROC1);
int bndry(int face0, int face1);

int * ipt(int l0, int l1, int l2);
int ** iup(int l0, int l1, int l2,int face0, int face1, int bndry, int ipt[]);
int ** idn(int l0, int l1, int l2,int face0, int face1, int bndry, int ipt[]);
int * map(int bndry, int ** iup, int ** idn, int l0, int l1, int l2, int ipt[]);

int * move_point(int x_global[], int ** iup, int ** idn, int ipt[], int map[], int **  cpr, int ** npr, int my_rank, int l0, int l1, int l2);
double measure(int x0, int x1, int x2, int y0, int y1, int y2, int nPROC0, int nPROC1, int l0, int l1);

#endif
