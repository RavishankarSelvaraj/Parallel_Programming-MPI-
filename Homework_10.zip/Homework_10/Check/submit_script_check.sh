#!/bin/bash
#
#SBATCH --nodes=2
#SBATCH --ntasks=4
#SBATCH --exclusive
#SBATCH --partition=compute2011


module load mpi/openmpi
mpicc -lm check.c header.h header.c;
mpirun -np 4 ./a.out < input.txt
