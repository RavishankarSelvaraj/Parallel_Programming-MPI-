
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include "header.h"
#include "mpi.h"

// 9.1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

// number of exterior boundary points in direction 0
int face0(int l0, int l1, int l2, int nPROC0) {
	if (nPROC0 == 1) { return 0; }
	else { return l1*l2; }//l0 = face0/2 , l1 = face1/2
}

// number of exterior boundary points in direction 1
int face1(int l0, int l1, int l2, int nPROC1) {
	if (nPROC1 == 1) { return 0; }
	else { return l0*l2; }
}

// total number of boundary points
int bndry(int face0, int face1) {
		return 2*(face0+face1);
}

// ipt[nl] is index of local point
int * ipt(int l0, int l1, int l2){
	int volume = l0*l1*l2;
	//printf("Local volume = %d", volume);
	int even = 0;
	int odd = volume/2;
	// x0=5(0,1,2,3,4),x1=5(0,1,2,3,4),x2=20(0-19)
	int* ipt = (int*)malloc(sizeof(int)*(volume));
	int nl;

	for(int i = 0; i < l2; i++){
		for(int j = 0; j < l1; j++){
			for(int k = 0; k < l0; k++){
				if ((i + j + k) % 2 == 0){
					ipt[even] = k + (j*l0) + (i*l0*l1); // nl = x0*L0 + x1*L0 + x2*L0*L2
					//printf("i = %2d, j = %2d, k = %2d\n", i, j, k);
					//printf("ipt[%2d] = %d\n", even, ipt[even]);
					even++;
				}
				else{
					ipt[odd] =  k + (j*l0) + (i*l0*l1); // nl = x0*L0 + x1*L0 + x2*L0*L2
					//printf("i = %2d, j = %2d, k = %2d\n", i, j, k);
					//printf("ipt[%2d] = %d\n", odd, ipt[odd]);
					odd++;
				}
			}
		}
	}
	return ipt;
}

// iup[ix][mu] is the index of nearest neighbor point in positive "up" direction
int ** iup(int l0, int l1, int l2,int face0, int face1, int bndry, int ipt[]){
	int volume = l0*l1*l2;
	int z = 0; // for "layers" in L2 direction
	int** iup = (int**)malloc(sizeof(int*)*(volume));

	for (int j = 0; j < (volume); j++) {
    		iup[j] = (int*)malloc(sizeof(int) * 2);
	}

	int bnd_pos_0_eve = volume + face0/2;
	int bnd_pos_1_eve = volume + face0 + face1/2;
	int bnd_pos_0_odd = volume + face0/2 + bndry/2; // boundary in positive 0 direction for odd points
	int bnd_pos_1_odd = volume + face0 + face1/2 + bndry/2;
	//printf("volume/2= %d\n", volume/2);

	// even points
	for (int i = 0; i < volume/2; i++){

		// up direction +0
		// check if point is on the boundary
		if ((((ipt[i] + 1) % l0 ) == 0) && (ipt[i] != 0))  {
			iup[i][0] = bnd_pos_0_eve;
			//printf("iup[%2d][0] = %d\n", i, iup[i][0]);
			bnd_pos_0_eve++;
		} else {
			iup[i][0] = ipt[i] + 1;
			//printf("iup[%2d][0] = %d\n", i, iup[i][0]);
		}

		// up direction +1
		// ckeck if point is on the boundary
		if ((ipt[i] > (l0*l1 - 1) - l0 + l0*l1*z ) && (ipt[i] <= (l0*l1) + l0*l1*z)) {
			iup[i][1] = bnd_pos_1_eve;
			//printf("iup[%2d][1] = %d\n", i, iup[i][1]);
			bnd_pos_1_eve++;
			if (ipt[i] >= (l0*l1) + l0*l1*z - 2){
				z++;
			}
		} else {
			iup[i][1] = ipt[i]+ l0;
			//printf("iup[%2d][1 ] = %d\n", i, iup[i][1]);
		}
	}

	//odd points
	z = 0;
	for (int k = volume/2; k < volume; k++) {

                // up direction +0
                if (((ipt[k] + 1) % l0) == 0)  {
                        iup[k][0] = bnd_pos_0_odd;
                        //printf("iup[%2d][0] = %d\n", k, iup[k][0]);
			bnd_pos_0_odd++;
                } else {

                        iup[k][0] = ipt[k] + 1;
                       // printf("iup[%2d][0] = %d\n", k, iup[k][0]);
                }

                // up direction +1
                if((ipt[k] > (l0*l1 - 1) - l0 +l0*l1*z) && (ipt[k] <= (l0*l1) + l0*l1*z)) {
                        iup[k][1] = bnd_pos_1_odd;
                        //printf("iup[%2d][1] = %d\n", k, iup[k][1]);
                        bnd_pos_1_odd++;
                        if (ipt[k] >= (l0*l1) + l0*l1*z - 2){
                                z++;
                        }
                } else {
                        iup[k][1] = ipt[k] + l0;
                        //printf("iup[%2d][1 ] = %d\n", k, iup[k][1]);
                }
	}
	return iup;
}

// idn[ix][mu] is the index of nearest neighbor point in negative "down" direction
int ** idn(int l0, int l1, int l2,int face0, int face1, int bndry, int ipt[]){

        int volume = l0*l1*l2; // volume of the local lattice
        int z = 0; // counter for the layers in L2 direction in the local lattice
        int** idn = (int**)malloc(sizeof(int*)*(volume));
        for (int j = 0; j < (volume); j++){
                idn[j] = (int*)malloc(sizeof(int) * 2);
        }

        // up array with even points on postive 0 and 1 direction
        int bnd_neg_0_eve = volume;
        int bnd_neg_1_eve = volume + face0;
        int bnd_neg_0_odd = volume + bndry/2; // boundary in negative 0 direction for odd points
        int bnd_neg_1_odd = volume + face0 + bndry/2;
	//printf("volume/2= %d\n", volume/2);

        // even points
        for (int i = 0; i < volume/2; i++) {

                // down direction -0
                // check if point is on the boundary
                if (((ipt[i] % l0 ) == 0 ) || (ipt[i] == 0))  {
                        idn[i][0] = bnd_neg_0_eve;
                      // printf("idn[%2d][0] = %d, v=%d\n", i, idn[i][0], ipt[i]);
                        bnd_neg_0_eve++;

                } else {
                        idn[i][0] = ipt[i] - 1;
                       // printf("idn[%2d][0] = %d\n", i, idn[i][0]);
                }

                // down direction -1
                // ckeck if point is on the boundary
                if( (ipt[i] >= l0*l1*z) && (ipt[i] < (l0 + l0*l1*z) )) {
                        idn[i][1] = bnd_neg_1_eve;
			//printf("idn[%2d][1] = %d\n", i, idn[i][1]);
                        bnd_neg_1_eve++;
                        if (ipt[i] >= (l0*l1*z + l0) - 2){
                                z++;
                        }
                } else {
                        idn[i][1] = ipt[i] - l0;
			//printf("idn[%2d][1 ] = %d\n", i, idn[i][1]);
                }
        }

        //odd points
        z = 0;
        for (int k = volume/2; k < volume; k++) {

                // down direction -0
		// ckeck if point is on the boundary
                if ((ipt[k] % l0 ) == 0)  {
                        idn[k][0] = bnd_neg_0_odd;
                        //printf("idn[%2d][0 ] = %d\n", k, idn[k][0]);
                        bnd_neg_0_odd++;
                } else {

                        idn[k][0] = ipt[k] - 1;
                        //printf("idn[%2d][0 ] = %d\n", k, idn[k][0]);
                }

                // down direction -1
		// check if point is on the boundary
                if((ipt[k] >= l0*l1*z) && (ipt[k] < (l0 + l0*l1*z))) {
                        idn[k][1] = bnd_neg_1_odd;
                        //printf("idn[%2d][1] = %d\n", k, idn[k][1]);
                        bnd_neg_1_odd++;
                        if (ipt[k] >= (l0*l1*z + l0) - 2){
                                z++;
                        }
                } else {
                        idn[k][1] = ipt[k] - l0;
                        //printf("idn[%2d][1 ] = %d\n", k, idn[k][1]);
                }
	}
        return idn;
}

// map[iy - volume] is the index of the point on the local lattice of neigboring process in direction +mu
int * map(int bndry, int ** iup, int ** idn, int l0, int l1, int l2, int ipt[]){
	int* map = (int*)malloc(sizeof(int)*(bndry));
	int volume = l0*l1*l2;
	int bnd[bndry];
	int z=0;
	int c=0;

	if(((l0*l1) - 1) % 2 == 0){
	// Read Even boundaary points
	//iup =550 to 599 -+ 0 even 
	for(int i = 0; i < volume/2; i++){
                if ((((ipt[i] + 1) % l0 ) == 0) && (ipt[i] != 0))  {
                        int a = ipt[i];
			bnd[z] = a;
			//printf("bnd[%2d] = %d\n", z, bnd[z]);
		        z++;
                 }
	}

	 //iup =500 to 550 --0 even
	for(int i = 0; i < volume/2; i++){
		if (((ipt[i] % l0 ) == 0) || (ipt[i] == 0))  {
                       	int b = ipt[i];
                        bnd[z] = b;
                        //printf("bnd[%2d] = %d\n", z, bnd[z]);
                        z++;
                }
	}

	//iup =600 to 649 - +1 even
	for(int i = 0; i < volume/2; i++) {
                // ckeck if point is on the boundary
                if ((ipt[i] > (l0*l1 - 1) - l0 + l0*l1*c ) && (ipt[i] <= (l0*l1) + l0*l1*c)) {
                        int d = ipt[i];
			bnd[z] = d;
                        //printf("bnd[%2d] = %d\n", z, bnd[z]);
                        z++;
                        if (ipt[i] >= (l0*l1) + l0*l1*c - 2){
                                c++;
                        }
                }
	 }

	//iup =649 to 699 --1 even
	c = 0;
	for(int i = 0; i < volume/2; i++){
	 	if( (ipt[i] >= l0*l1*c) && (ipt[i] < (l0 + l0*l1*c) )) {
                        int e = ipt[i];
                        bnd[z] = e;
                        //printf("bnd[%2d] = %d\n", z, bnd[z]);
                        z++;
                        if (ipt[i] >= (l0*l1*c + l0) - 2){
                                c++;
                        }
                }
	}

	//Read Odd boundary numbers
	//idn = 700 to 749 =+0 odd
        for(int i = volume/2; i < volume; i++){
                if (((ipt[i] + 1) % l0) == 0)  {
                        int f = ipt[i];
                        bnd[z] = f;
                       // printf("bnd[%2d] = %d\n", z, bnd[z]);
                        z++;
                }
        }

	//idn = 750 to 799 = - 0 odd
        for(int i = volume/2; i < volume; i++){
                if ((ipt[i] % l0 ) == 0)  {
                        int g = ipt[i];
                        bnd[z] = g;
                        //printf("bnd[%2d] = %d\n", z, bnd[z]);
                        z++;
                }
        }

	//idn = 800 to 849 = +1 odd
        c = 0;
        for(int i = volume/2; i < volume; i++) {
                 if((ipt[i] > (l0*l1 - 1) - l0 +l0*l1*c) && (ipt[i] <= (l0*l1) + l0*l1*c)) {
                        int h = ipt[i];
                        bnd[z] = h;
                        //printf("bnd[%2d] = %d\n", z, bnd[z]);
                        z++;
                        if (ipt[i] >= (l0*l1) + l0*l1*c - 2){
                                c++;
                        }
                }
        }

	//idn = 850 to 899 = -1 odd
	c = 0;
	for(int i = volume/2; i < volume; i++){
		if((ipt[i] >= l0*l1*c) && (ipt[i] < (l0 + l0*l1*c))) {
                        int k = ipt[i];
                        bnd[z] = k;
                        //printf("bnd[%2d] = %d\n", z, bnd[z]);
                        z++;
                        if (ipt[i] >= (l0*l1*c + l0) - 2){
                                c++;
                        }
                }
	}

	//mapping
	z = 0;
	// for +0 even = idn 0
	for (int j = 0; j < volume/2; j++){
			if((idn[j][0] >= volume) && (idn[j][0]<= volume+bndry)) {
			int iy = idn[j][0] - volume;
			map[iy] = bnd[z];
			//printf("idn[%2d][0]= %2d, bnd[%d] = %d, map[%2d] = %d\n", j,idn[j][0],z,bnd[z], iy, map[iy]);
			z++;
			}
	}

	// for -0 even = iup 0
	for (int j = 0; j < volume/2; j++){
                        if((iup[j][0] >= volume) && (iup[j][0]<= volume+bndry)) {
                        int iy = iup[j][0] - volume;
                        map[iy] = bnd[z];
                        //printf("iup[%2d][0]= %2d, bnd[%d] = %d, map[%2d] = %d\n", j,iup[j][0],z,bnd[z], iy, map[iy]);
                        z++;
                        }
        }

	// for +1 even = idn 1
	for (int j = 0; j < volume/2; j++){
                        if((idn[j][1] >= volume) && (idn[j][1]<= volume+bndry)) {
                        int iy = idn[j][1] - volume;
                        map[iy] = bnd[z];
                        //printf("idn[%2d][1]= %2d, bnd[%d] = %d, map[%2d] = %d\n", j,idn[j][1],z,bnd[z], iy, map[iy]);
                        z++;
                        }
	}

	 // for -1 even = iup 1
	for (int j = 0; j < volume/2; j++){
                        if((iup[j][1] >= volume) && (iup[j][1]<= volume+bndry)) {
                        int iy = iup[j][1] - volume;
                        map[iy] = bnd[z];
                        //printf("iup[%2d][1]= %2d, bnd[%d] = %d, map[%2d] = %d\n", j,iup[j][1],z,bnd[z], iy, map[iy]);
                        z++;
                        }
        }

	 // for +0 odd = idn 0
        for (int j = volume/2; j < volume; j++){
                        if((idn[j][0] >= volume) && (idn[j][0]<= volume+bndry)) {
                        int iy = idn[j][0] - volume;
                        map[iy] = bnd[z];
                        //printf("idn[%2d][0]= %2d, bnd[%d] = %d, map[%2d] = %d\n", j,idn[j][0],z,bnd[z], iy, map[iy]);
                        z++;
                        }
        }

        // for -0 odd = iup 0
        for (int j = volume/2; j < volume; j++){
                        if((iup[j][0] >= volume) && (iup[j][0]<= volume+bndry)) {
                        int iy = iup[j][0] - volume;
                        map[iy] = bnd[z];
                        //printf("iup[%2d][0]= %2d, bnd[%d] = %d, map[%2d] = %d\n", j,iup[j][0],z,bnd[z], iy, map[iy]);
                        z++;
                        }
        }

        // for +1 odd = idn 1
        for (int j = volume/2; j < volume; j++){
                        if((idn[j][1] >= volume) && (idn[j][1]<= volume+bndry)) {
                        int iy = idn[j][1] - volume;
                        map[iy] = bnd[z];
                       // printf("idn[%2d][1]= %2d, bnd[%d] = %d, map[%2d] = %d\n", j,idn[j][1],z,bnd[z], iy, map[iy]);
                        z++;
                        }
        }

         // for -1 odd = iup 1
        for (int j = volume/2; j < volume; j++){
                        if((iup[j][1] >= volume) && (iup[j][1]<= volume+bndry)) {
                        int iy = iup[j][1] - volume;
                        map[iy] = bnd[z];
                        //printf("iup[%2d][1]= %2d, bnd[%d] = %d, map[%2d] = %d\n", j,iup[j][1],z,bnd[z], iy, map[iy]);
                        z++;
                        }
        }

	} else {
	// Read Even boundaary points
	//iup =550 to 599 -+ 0 even 
	for(int i = 0; i < volume/2; i++){
                if ((((ipt[i] + 1) % l0 ) == 0) && (ipt[i] != 0)) {
                        int a = ipt[i];
			bnd[z] = a;
			//printf("bnd[%2d] = %d\n", z, bnd[z]);
		        z++;
                 }
	}

	 //iup =500 to 550 --0 even
	for(int i = 0; i < volume/2; i++){
		if (((ipt[i] % l0 ) == 0) || (ipt[i] == 0))  {
                       	int b = ipt[i];
                        bnd[z] = b;
                        //printf("bnd[%2d] = %d\n", z, bnd[z]);
                        z++;
                }
	}

	//iup =600 to 649 - +1 even
	//z+=bnd_eights;
	for(int i = 0; i < volume/2; i++){
                // ckeck if point is on the boundary
                if ((ipt[i] > (l0*l1 - 1) - l0 + l0*l1*c ) && (ipt[i] <= (l0*l1) + l0*l1*c)) {
                        int d = ipt[i];
			bnd[z] = d;
                        //printf("bnd[%2d] = %d\n", z, bnd[z]);
                        z++;
                        if (ipt[i] >= (l0*l1) + l0*l1*c - 2){
                                c++;
                        }
                }
	 }

	//iup =649 to 699 --1 even
	c = 0;
	for(int i = 0; i < volume/2; i++){
	 	if( (ipt[i] >= l0*l1*c) && (ipt[i] < (l0 + l0*l1*c) )) {
                        int e = ipt[i];
                        bnd[z] = e;
                        //printf("bnd[%2d] = %d\n", z, bnd[z]);
                        z++;
                        if (ipt[i] >= (l0*l1*c + l0) - 2){
                                c++;
                        }
                }
	}

	//Read Odd boundary numbers
	//idn = 700 to 749 =+0 odd
        for(int i = volume/2; i < volume; i++){
                if (((ipt[i] + 1) % l0) == 0)  {
                        int f = ipt[i];
                        bnd[z] = f;
                       // printf("bnd[%2d] = %d\n", z, bnd[z]);
                        z++;
                }
        }

	//idn = 750 to 799 = - 0 odd
        for(int i = volume/2; i < volume; i++){
                if ((ipt[i] % l0 ) == 0)  {
                        int g = ipt[i];
                        bnd[z] = g;
                        //printf("bnd[%2d] = %d\n", z, bnd[z]);
                        z++;
                }
        }

	//idn = 800 to 849 = +1 odd
        c = 0;
        for(int i = volume/2; i < volume; i++){
                 if((ipt[i] > (l0*l1 - 1) - l0 +l0*l1*c) && (ipt[i] <= (l0*l1) + l0*l1*c)) {
                        int h = ipt[i];
                        bnd[z] = h;
                        //printf("bnd[%2d] = %d\n", z, bnd[z]);
                        z++;
                        if (ipt[i] >= (l0*l1) + l0*l1*c - 2){
                                c++;
                        }
                }
        }

	//idn = 850 to 899 = -1 odd
	c = 0;
	for(int i = volume/2; i < volume; i++){
		if((ipt[i] >= l0*l1*c) && (ipt[i] < (l0 + l0*l1*c))) {
                        int k = ipt[i];
                        bnd[z] = k;
                        //printf("bnd[%2d] = %d\n", z, bnd[z]);
                        z++;
                        if (ipt[i] >= (l0*l1*c + l0) - 2){
                                c++;
                        }
                }
	}

	//mapping
	z = 0;
	 // for +0 odd = idn 0
        for (int j = volume/2; j < volume; j++){
                        if((idn[j][0] >= volume) && (idn[j][0]<= volume+bndry)) {
                        int iy = idn[j][0] - volume;
                        map[iy] = bnd[z];
                        //printf("idn[%2d][0]= %2d, bnd[%d] = %d, map[%2d] = %d\n", j,idn[j][0],z,bnd[z], iy, map[iy]);
                        z++;
                        }
        }

	// for -0 odd = iup 0
        for (int j = volume/2; j < volume; j++){
                        if((iup[j][0] >= volume) && (iup[j][0]<= volume+bndry)) {
                        int iy = iup[j][0] - volume;
                        map[iy] = bnd[z];
                        //printf("iup[%2d][0]= %2d, bnd[%d] = %d, map[%2d] = %d\n", j,iup[j][0],z,bnd[z], iy, map[iy]);
                        z++;
                        }
        }

        // for +1 odd = idn 1
        for (int j = volume/2; j < volume; j++){
                        if((idn[j][1] >= volume) && (idn[j][1]<= volume+bndry)) {
                        int iy = idn[j][1] - volume;
                        map[iy] = bnd[z];
                       	//printf("idn[%2d][1]= %2d, bnd[%d] = %d, map[%2d] = %d\n", j,idn[j][1],z,bnd[z], iy, map[iy]);
                        z++;
                        }
        }

         // for -1 odd = iup 1
        for (int j = volume/2; j < volume; j++){
                        if((iup[j][1] >= volume) && (iup[j][1]<= volume+bndry)) {
                        int iy = iup[j][1] - volume;
                        map[iy] = bnd[z];
                        //printf("iup[%2d][1]= %2d, bnd[%d] = %d, map[%2d] = %d\n", j,iup[j][1],z,bnd[z], iy, map[iy]);
                        z++;
                        }
        }

	// for +0 even = idn 0
	for (int j = 0; j < volume/2; j++){
			if((idn[j][0] >= volume) && (idn[j][0]<= volume+bndry)) {
			int iy = idn[j][0] - volume;
			map[iy] = bnd[z];
			//printf("idn[%2d][0]= %2d, bnd[%d] = %d, map[%2d] = %d\n", j,idn[j][0],z,bnd[z], iy, map[iy]);
			z++;
			}
	}

	// for -0 even = iup 0
	for (int j = 0; j < volume/2; j++){
                        if((iup[j][0] >= volume) && (iup[j][0]<= volume+bndry)) {
                        int iy = iup[j][0] - volume;
                        map[iy] = bnd[z];
                       	//printf("iup[%2d][0]= %2d, bnd[%d] = %d, map[%2d] = %d\n", j,iup[j][0],z,bnd[z], iy, map[iy]);
                        z++;
                        }
        }

	// for +1 even = idn 1
	for (int j = 0; j < volume/2; j++){
                        if((idn[j][1] >= volume) && (idn[j][1]<= volume+bndry)) {
                        int iy = idn[j][1] - volume;
                        map[iy] = bnd[z];
                        //printf("idn[%2d][1]= %2d, bnd[%d] = %d, map[%2d] = %d\n", j,idn[j][1],z,bnd[z], iy, map[iy]);
                        z++;
                        }
	}

	 // for -1 even = iup 1
	for (int j = 0; j < volume/2; j++){
                        if((iup[j][1] >= volume) && (iup[j][1]<= volume+bndry)) {
                        int iy = iup[j][1] - volume;
                        map[iy] = bnd[z];
                        //printf("iup[%2d][1]= %2d, bnd[%d] = %d, map[%2d] = %d\n", j,iup[j][1],z,bnd[z], iy, map[iy]);
                        z++;
                        }
        }
	}

	return map;
}

// 9.2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


// move one step from one point to another in the random walk
int * move_point(int x_global[], int ** iup, int ** idn, int ipt[], int map[], int **  cpr, int ** npr, int my_rank, int l0, int l1, int l2){

	int volume =  l0*l1*l2;
	int * move = (int*)malloc(sizeof(int)*(4)); // 0: x0, 1: x1, 2: x2, 3: rank_new
	int rank_new;
	int x0_new = x_global[0] - cpr[my_rank][0]*l0;
	int x1_new = x_global[1] - cpr[my_rank][1]*l1;
	int x2_new = x_global[2];
	int nl = x0_new + x1_new*l1 + x2_new*l0*l1;
	move[0] = x0_new;
	move[1] = x1_new;
	move[2] = x2_new;
	//srand(time(0));
	int x0,x1,x2,x3,r_1;
        int nl_change;
	int rand_dir = rand() % 6;
	//printf("rank = %d, npr[0] = %d, npr[1] = %d, npr[2] = %d, npr[3] = %d, cpr[0] = %d, cpr[1] =%d, x0 = %d, x1 = %d, x2 = %d \n" , my_rank, npr[0] , npr[1],  npr[2] , npr[3], cpr[0], cpr[1] ,x_global[0], x_global[1], x_global[2]);
	//printf("random direction = %d\n", rand_dir);
	//printf("x0_local = %d, x1_local = %d, x2_local = %d\n", x0_new, x1_new, x2_new);
	switch (rand_dir) {

		// -0 direction
		case 0:	
                        for(int i = 0; i<volume; i++){
                                if(ipt[i] == nl){
                                        if (idn[i][0]<volume){
                                                nl_change = idn[i][0];
                                                move[0] = nl_change - x1_new*l1 - x2_new*l0*l1;
                                                move[3] = my_rank;
                                                move[4] = 0;
                                                //printf("The nl value is %d and the -0 direction is %d\n",nl,move[0]);
                                                break;
                                        } else{
                                                nl_change = map[idn[i][0] - volume];
                                                move[0] = nl_change - x1_new*l1 - x2_new*l0*l1;
                                                move[3] = npr[my_rank][0];
                                                move[4] = 0;
                                                //printf("The nl value is %d and the -0 direction is %d\n",nl,move[0]);
                                                break;
                                        }
                                }
                         }
                        break;

		// +0 direction
		case 1:
			for(int i = 0; i<volume; i++){
                                if(ipt[i] == nl){
                                        if (iup[i][0]<volume){
                                                nl_change = iup[i][0];
                                                move[0] = nl_change - x1_new*l1 - x2_new*l0*l1;
                                                move[3] = my_rank;
                                                move[4] = 0;
                                                //printf("The nl value is %d and the -0 direction is %d\n",nl,move[0]);
                                                break;
                                        } else{
                                                nl_change = map[iup[i][0] - volume];
                                                move[0] = nl_change - x1_new*l1 - x2_new*l0*l1;
                                                move[3] = npr[my_rank][1];
                                                move[4] = 0;
                                                //printf("The nl value is %d and the -0 direction is %d\n",nl,move[0]);
                                                //printf("The ipt value is %d and the -0 direction is %d\n",nl1,x);
                                                break;
                                        }
                                }
                         }
                        break;

		// -1  direction
		case 2:
			for(int i = 0; i<volume; i++){
                                if(ipt[i] == nl){
                                        if (idn[i][1]<volume){
                                                nl_change = idn[i][1];
                                                move[1] = (nl_change - x0_new - x2_new*l0*l1)/l1;
                                                move[3] = my_rank;
                                                move[4] = 1;
                                                //printf("The nl value is %d and the -0 direction is %d\n",nl,move[0]);
                                                break;
                                        } else{
                                                nl_change = map[idn[i][1] - volume];
                                                move[1] = (nl_change - x0_new - x2_new*l0*l1)/l1;
                                                move[3] = npr[my_rank][2];
                                                move[4] = 1;
                                                //printf("The nl value is %d and the -0 direction is %d\n",nl,move[0]);
                                                break;
                                        }
                                }
                        }
                        break;
		// +1 direction
		case 3:
                        for(int i = 0; i<volume; i++){
                                if(ipt[i] == nl){
                                        if (iup[i][1]<volume){
                                                nl_change = iup[i][1];
                                                move[1] = (nl_change - x0_new - x2_new*l0*l1)/l1;
                                                move[3] = my_rank;
                                                move[4] = 1;
                                                //printf("The nl value is %d and the -0 direction is %d\n",nl,move[0]);
                                                break;
                                        } else{
                                                nl_change = map[iup[i][1] - volume];
                                                move[1] = (nl_change - x0_new - x2_new*l0*l1)/l1;
                                                move[3] = npr[my_rank][3];
                                                move[4] = 1;
                                                //printf("The nl value is %d and the -0 direction is %d\n",nl,move[0]);
                                                break;
                                        }
                                }
                        }
                        break;
		// -2 direction
		case 4:
                        if((x2_new <= (l2-1) && (x2_new !=0 ))){
				move[3] = my_rank;
				move[2] = x2_new - 1;
                                move[4] = 2;
			} else {
				move[3] = my_rank;
				move[2] = x2_new + (l2-1);
                                move[4] = 2;
			}
			break;
		// +2 direction
                case 5:
			if((x2_new < (l2-1))){
                                move[3] = my_rank;
                                move[2] = x2_new + 1;
                                move[4] = 2;
                        } else {
                                move[3] = my_rank;
                                move[2] = x2_new - (l2-1);
                                move[4] = 2;
                        }
                        break;
	}

	return move;
}




