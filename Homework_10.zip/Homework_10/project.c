/*
 * Homework 10
 *
 * Lattice Setup
 * author: Ravishankar Selvaraj (2036915) Dominik Wirsig (2020067)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "header.h"
#include "mpi.h"

// create struct with person1 variable
struct field {
  double fi1;
  double fi2;
};

// we wanted to put this function into the header.c file. 
// sending field values at even and odd points of the local lattice whose neigbors are physically on a neigboring local lattice
void sendfunc(struct field *fi, int npr[],int ipt[], int map[], int **iup, int **idn, int f0,int f1, int l0, int l1, int l2, int bnd, int my_rank, MPI_Comm cart_comm, MPI_Status status, int nPROC0, int nPROC1){
	
        	int volume = l0 * l1 * l2;
                double start,finish;
		// exterior boundary points
		// temporary arrays to store the boundary points
		struct field * tmp_neg_0_even = (struct field * )malloc(sizeof(struct field)*(f0/2));
                struct field * tmp_pos_0_even = (struct field * )malloc(sizeof(struct field)*(f0/2));
                struct field * tmp_neg_1_even = (struct field * )malloc(sizeof(struct field)*(f1/2));
                struct field * tmp_pos_1_even = (struct field * )malloc(sizeof(struct field)*(f1/2));
                struct field * tmp_neg_0_odd = (struct field * )malloc(sizeof(struct field)*(f0/2));
                struct field * tmp_pos_0_odd = (struct field * )malloc(sizeof(struct field)*(f0/2));
                struct field * tmp_neg_1_odd = (struct field * )malloc(sizeof(struct field)*(f1/2));
                struct field * tmp_pos_1_odd = (struct field * )malloc(sizeof(struct field)*(f1/2));

        if(((l0*l1) - 1) % 2 == 0){

                // Mapping for lattice whose starting and ending points were even
                //Assigning values to temporary array from boundary points
   		// - 0 direction even (500-549)
                int j = 0;
		for (int i = 0; i < volume/2; i++) {
                        if((idn[i][0] >= volume) && (idn[i][0]<= volume+bnd)) {
        		        tmp_neg_0_even[j].fi1 = fi[i].fi1;
			        tmp_neg_0_even[j].fi2 = fi[i].fi2;
                                //printf("no . %d, the value of fi[%d], temp = %d\n",i, i, j );
                                //printf("-ve 1 even value of fi[%d]= %f ,fi[%d]= %f\n",i, fi[i].fi1 ,i, fi[i].fi2 );
                                j++;
                        }      
    		}
                j = 0;
		// +0 direction even (550-599)
		for (int i = 0; i < volume/2; i++) {
                        if((iup[i][0] >= volume) && (iup[i][0]<= volume+bnd)) {
                                tmp_pos_0_even[j].fi1 = fi[i].fi1;
                                tmp_pos_0_even[j].fi2 = fi[i].fi2;
                                //printf(" no . %d, the value of fi[%d], temp = %d\n",i, i, j );
                                j++;
                        }
                }
                j = 0;
		// - 1 direction even (600-649)
                for (int i = 0; i < volume/2; i++) {
                        if((idn[i][1] >= volume) && (idn[i][1]<= volume+bnd)) {
                                tmp_neg_1_even[j].fi1 = fi[i].fi1;
                                tmp_neg_1_even[j].fi2 = fi[i].fi2;
                                //printf(" no . %d, the value of fi[%d], temp = %d\n",i, i, j );
                                j++;
                        }
                }
                j = 0;
                // +1 direction even (650-699)
                for (int i = 0; i < volume/2; i++) {
                        if((iup[i][1] >= volume) && (iup[i][1]<= volume+bnd)) {
                                tmp_pos_1_even[j].fi1 = fi[i].fi1;
                                tmp_pos_1_even[j].fi2 = fi[i].fi2;
                                //printf(" no . %d, the value of fi[%d], temp = %d\n",i, i, j );
                                j++;
                        }
                }

		//odd direction
                j = 0;
		// - 0 direction odd (700-749)
                for(int i = (volume/2); i < volume; i++) {
                        if((idn[i][0] >= volume) && (idn[i][0]<= volume+bnd)) {
                                tmp_neg_0_odd[j].fi1 = fi[i].fi1;
                                tmp_neg_0_odd[j].fi2 = fi[i].fi2;
                                //printf(" no . %d, the value of fi[%d], temp = %d\n",i, i, j );
                                j++;
                        }
                }
                j = 0;
                // +0 direction odd (750-799)
                for (int i = volume/2; i < volume; i++) {
                        if((iup[i][0] >= volume) && (iup[i][0]<= volume+bnd)) {
                                tmp_pos_0_odd[j].fi1 = fi[i].fi1;
                                tmp_pos_0_odd[j].fi2 = fi[i].fi2;
                                //printf(" no . %d, the value of fi[%d], temp = %d\n",i, i, j );
                                j++;
                        }
                }
                j = 0;
                // - 1 direction odd (800-849)
                 for (int i =volume/2; i < volume; i++) {
                        if((idn[i][1] >= volume) && (idn[i][1]<= volume+bnd)) {
                                tmp_neg_1_odd[j].fi1 = fi[i].fi1;
                                tmp_neg_1_odd[j].fi2 = fi[i].fi2;
                                //printf(" no . %d, the value of fi[%d], temp = %d\n",i, i, j );
                                j++;
                        }
                }
                j = 0;
                // +1 direction odd (850-899)
                for (int i = volume/2; i < volume; i++) {
                        if((iup[i][1] >= volume) && (iup[i][1]<= volume+bnd)) {
                                tmp_pos_1_odd[j].fi1 = fi[i].fi1;
                                tmp_pos_1_odd[j].fi2 = fi[i].fi2;
                                //printf(" no . %d, the value of fi[%d], temp = %d\n",i, i, j );
                                j++;
                        }

                }     
		// send and receive the even exterior boundary values to the right processor first
                // timing
		MPI_Barrier(MPI_COMM_WORLD);
                start = MPI_Wtime();

       		//send  -ve 0 even to +ve 0 even
		MPI_Send(tmp_neg_0_even, f0, MPI_DOUBLE, npr[0], 0, cart_comm); //-0 direction even
                MPI_Send(tmp_pos_0_even, f0, MPI_DOUBLE, npr[1], 1, cart_comm); //+0 direction even
                MPI_Send(tmp_neg_1_even, f1, MPI_DOUBLE, npr[2], 2, cart_comm); //-1 direction even
                MPI_Send(tmp_pos_1_even, f1, MPI_DOUBLE, npr[3], 3, cart_comm); //+1 direction even


                MPI_Recv(tmp_pos_0_even, f0, MPI_DOUBLE, npr[1], 0, cart_comm, &status);// stored in +0 direction		
                MPI_Recv(tmp_neg_0_even, f0, MPI_DOUBLE, npr[0], 1, cart_comm, &status);// stored in -0 direction          
		MPI_Recv(tmp_pos_1_even, f1, MPI_DOUBLE, npr[3], 2, cart_comm, &status);// stored in +1 direction
                MPI_Recv(tmp_neg_1_even, f1, MPI_DOUBLE, npr[2], 3, cart_comm, &status);// stored in -1 direction	
		
                // send and receive the odd exterior boundary values to the right processor second
                //send  -ve 0 odd to +ve 0 odd
		MPI_Send(tmp_neg_0_odd, f0, MPI_DOUBLE, npr[0], 4, cart_comm); //-0 direction odd
                MPI_Send(tmp_pos_0_odd, f0, MPI_DOUBLE, npr[1], 5, cart_comm); //+0 direction odd
                MPI_Send(tmp_neg_1_odd, f1, MPI_DOUBLE, npr[2], 6, cart_comm); //-1 direction odd
                MPI_Send(tmp_pos_1_odd, f1, MPI_DOUBLE, npr[3], 7, cart_comm); //+1 direction odd


                MPI_Recv(tmp_pos_0_odd, f0, MPI_DOUBLE, npr[1], 4, cart_comm, &status);// stored in +0 direction                
                MPI_Recv(tmp_neg_0_odd, f0, MPI_DOUBLE, npr[0], 5, cart_comm, &status);// stored in -0 direction              
                MPI_Recv(tmp_pos_1_odd, f1, MPI_DOUBLE, npr[3], 6, cart_comm, &status);// stored in +1 direction
                MPI_Recv(tmp_neg_1_odd, f1, MPI_DOUBLE, npr[2], 7, cart_comm, &status);// stored in -1 direction
		
                // stop timing
		MPI_Barrier(MPI_COMM_WORLD);
                finish = MPI_Wtime();

                        // updating the exterior boundary points to the local lattice from temporary array 
                        // - 0 direction even (500-549)
		        for (int i = 0; i < f0/2; i++) {
        		        fi[i + volume].fi1 = tmp_neg_0_even[i].fi1; 
			        fi[i + volume].fi2 = tmp_neg_0_even[i].fi2; 
    		        }
		        // +0 direction even (550-599) 
		        for (int i = 0; i < f0/2; i++) {
                                fi[i + volume + f0/2].fi1 = tmp_pos_0_even[i].fi1; 
                                fi[i + volume + f0/2].fi2 = tmp_pos_0_even[i].fi2;
                        }
		        // - 1 direction even (600-649) 
                        for (int i = 0; i < f1/2; i++) {
                                fi[i + volume + f0].fi1 = tmp_neg_1_even[i].fi1;
                                fi[i + volume + f0].fi2 = tmp_neg_1_even[i].fi2;
                        }
                        // +1 direction even (650-699) 
                        for (int i = 0; i < f1/2; i++) {
                                fi[i+ volume+ f0 + f1/2].fi1 = tmp_pos_1_even[i].fi1;
                                fi[i+ volume+ f0 + f1/2].fi2 = tmp_pos_1_even[i].fi2;
                        }

		        //odd direction
		        // - 0 direction odd (700-749) 
                        for (int i = 0; i < f0/2; i++) {
                                fi[i + volume + bnd/2].fi1 = tmp_neg_0_odd[i].fi1;
                                fi[i + volume + bnd/2].fi2 = tmp_neg_0_odd[i].fi2;
                        }
                        // +0 direction odd (750-799) 
                        for (int i = 0; i < f0/2; i++) {
                                fi[i + volume + f0/2 + bnd/2].fi1 = tmp_pos_0_odd[i].fi1;
                                fi[i + volume + f0/2 + bnd/2].fi2 = tmp_pos_0_odd[i].fi2;
                        }
                        // - 1 direction odd (800-849) 
                        for (int i = 0; i < f1/2; i++) {
                                fi[i + volume + f0 + bnd/2].fi1 = tmp_neg_1_odd[i].fi1;
                                fi[i + volume + f0 + bnd/2].fi2 = tmp_neg_1_odd[i].fi2;
                        }
                        // +1 direction odd (850-899) 
                        for (int i = 0; i < f1/2; i++) {
                                fi[i+ volume+ f0 + f1/2 + bnd/2].fi1 = tmp_pos_1_odd[i].fi1;
                                fi[i+ volume+ f0 + f1/2 + bnd/2].fi2 = tmp_pos_1_odd[i].fi2;
                        }
                

                // Communication time taken by each processor
                MPI_Barrier(MPI_COMM_WORLD);
                for(int i = 0; i < ((nPROC0*nPROC1) - 1); i++){
                        if(my_rank == i){
                                printf("\t\t\t\t\tCommunication Time taken by Processor %d = %e milliseconds \n", my_rank, finish -start);
                        }
                }
        } else {
              
                // Mapping for lattice whose starting points were even and ending points were odd
                //Assigning values to temporary array from boundary points
   		// - 0 direction even (500-549)
                int j = 0;
		for (int i = 0; i < volume/2; i++) {
                        if((idn[i][0] >= volume) && (idn[i][0]<= volume+bnd)) {
        		        tmp_neg_0_even[j].fi1 = fi[i].fi1;
			        tmp_neg_0_even[j].fi2 = fi[i].fi2;
                                //printf("no . %d, the -ve zero even value of fi[%d], temp = %d\n",i, i, j );
                                //printf("-ve 0 even value of fi[%d]= %f ,fi[%d]= %f\n",i, fi[i].fi1, i, fi[i].fi2 );
                                j++;
                        }      
    		}
                j = 0;
		// +0 direction even (550-599)
		for (int i = 0; i < volume/2; i++) {
                        if((iup[i][0] >= volume) && (iup[i][0]<= volume+bnd)) {
                                tmp_pos_0_even[j].fi1 = fi[i].fi1;
                                tmp_pos_0_even[j].fi2 = fi[i].fi2;
                                //printf(" no . %d, the +ve 0 even value of fi[%d], temp = %d\n",i, i, j );
                                //printf("+ve 0 even value of fi[%d]= %f ,fi[%d]= %f\n",i, fi[i].fi1 ,i, fi[i].fi2 );
                                j++;
                        }
                }
                j = 0;
		// - 1 direction even (600-649)
                for (int i = 0; i < volume/2; i++) {
                        if((idn[i][1] >= volume) && (idn[i][1]<= volume+bnd)) {
                                tmp_neg_1_even[j].fi1 = fi[i].fi1;
                                tmp_neg_1_even[j].fi2 = fi[i].fi2;
                                //printf(" no . %d, the -ve 1 even value of fi[%d], temp = %d\n",i, i, j );
                                //printf("-ve 1 even value of fi[%d]= %f ,fi[%d]= %f\n",i, fi[i].fi1 ,i, fi[i].fi2 );
                                j++;
                        }
                }
                j = 0;
                // +1 direction even (650-699)
                for (int i = 0; i < volume/2; i++) {
                        if((iup[i][1] >= volume) && (iup[i][1]<= volume+bnd)) {
                                tmp_pos_1_even[j].fi1 = fi[i].fi1;
                                tmp_pos_1_even[j].fi2 = fi[i].fi2;
                                //printf(" no . %d, the +ve 1 even value of fi[%d], temp = %d\n",i, i, j );
                               //printf("+ve 1 even value of fi[%d]= %f ,fi[%d]= %f\n",i, fi[i].fi1, i, fi[i].fi2 );
                                j++;
                        }
                }

		//odd direction
                j = 0;
		// - 0 direction odd (700-749)
                for(int i = (volume/2); i < volume; i++) {
                        if((idn[i][0] >= volume) && (idn[i][0]<= volume+bnd)) {
                                tmp_neg_0_odd[j].fi1 = fi[i].fi1;
                                tmp_neg_0_odd[j].fi2 = fi[i].fi2;
                                //printf(" no . %d, the value of fi[%d], temp = %d\n",i, i, j );
                                //printf("-ve 0 odd value of fi[%d]= %f ,fi[%d]= %f\n",i, fi[i].fi1, i, fi[i].fi2 );
                                j++;
                        }
                }
                j = 0;
                // +0 direction odd (750-799)
                for (int i = volume/2; i < volume; i++) {
                        if((iup[i][0] >= volume) && (iup[i][0]<= volume+bnd)) {
                                tmp_pos_0_odd[j].fi1 = fi[i].fi1;
                                tmp_pos_0_odd[j].fi2 = fi[i].fi2;
                                //printf(" no . %d, the value of fi[%d], temp = %d\n",i, i, j );
                                //printf("+ve 0 odd value of fi[%d]= %f ,fi[%d]= %f\n",i, fi[i].fi1, i, fi[i].fi2 );
                                j++;
                        }
                }
                j = 0;
                // - 1 direction odd (800-849)
                 for (int i =volume/2; i < volume; i++) {
                        if((idn[i][1] >= volume) && (idn[i][1]<= volume+bnd)) {
                                tmp_neg_1_odd[j].fi1 = fi[i].fi1;
                                tmp_neg_1_odd[j].fi2 = fi[i].fi2;
                                //printf(" no . %d, nly -ve 1 the value of fi[%d], temp = %d\n",i, i, j );
                                //printf("-ve 1 odd value of fi[%d]= %f ,fi[%d]= %f\n",i, fi[i].fi1, i, fi[i].fi2 );
                                j++;
                        }
                }
                j = 0;
                // +1 direction odd (850-899)
                for (int i = volume/2; i < volume; i++) {
                        if((iup[i][1] >= volume) && (iup[i][1]<= volume+bnd)) {
                                tmp_pos_1_odd[j].fi1 = fi[i].fi1;
                                tmp_pos_1_odd[j].fi2 = fi[i].fi2;
                                //printf(" no . %d, the value of fi[%d], temp = %d\n",i, i, j );
                                //printf("+ve 1 odd value of fi[%d]= %f ,fi[%d]= %f\n",i, fi[i].fi1, i, fi[i].fi2 );
                                j++;
                        }

                }                     
                
                // timing
                MPI_Barrier(MPI_COMM_WORLD);
                start = MPI_Wtime();

                // send and receive the even exterior boundary values to the right processor first
       		//send  -ve 0 even to +ve 0 even
		MPI_Send(tmp_neg_0_even, f0, MPI_DOUBLE, npr[0], 0, cart_comm); //-0 direction even
                MPI_Send(tmp_pos_0_even, f0, MPI_DOUBLE, npr[1], 1, cart_comm); //+0 direction even
                MPI_Send(tmp_neg_1_even, f1, MPI_DOUBLE, npr[2], 2, cart_comm); //-1 direction even
                MPI_Send(tmp_pos_1_even, f1, MPI_DOUBLE, npr[3], 3, cart_comm); //+1 direction even

                //send  -ve 0 odd to +ve 0 odd
		MPI_Send(tmp_neg_0_odd, f0, MPI_DOUBLE, npr[0], 4, cart_comm); //-0 direction odd
                MPI_Send(tmp_pos_0_odd, f0, MPI_DOUBLE, npr[1], 5, cart_comm); //+0 direction odd
                MPI_Send(tmp_neg_1_odd, f1, MPI_DOUBLE, npr[2], 6, cart_comm); //-1 direction odd
                MPI_Send(tmp_pos_1_odd, f1, MPI_DOUBLE, npr[3], 7, cart_comm); //+1 direction odd

                // send and receive the odd exterior boundary values to the right processor second
                MPI_Recv(tmp_pos_0_odd, 2*f0, MPI_DOUBLE, npr[1], 0, cart_comm, &status);// stored in +0 direction		
                MPI_Recv(tmp_neg_0_odd, 2*f0, MPI_DOUBLE, npr[0], 1, cart_comm, &status);// stored in -0 direction          
		MPI_Recv(tmp_pos_1_odd, 2*f1, MPI_DOUBLE, npr[3], 2, cart_comm, &status);// stored in +1 direction
                MPI_Recv(tmp_neg_1_odd, 2*f1, MPI_DOUBLE, npr[2], 3, cart_comm, &status);// stored in -1 direction

                MPI_Recv(tmp_pos_0_even, f0, MPI_DOUBLE, npr[1], 4, cart_comm, &status);// stored in +0 direction                
                MPI_Recv(tmp_neg_0_even, f0, MPI_DOUBLE, npr[0], 5, cart_comm, &status);// stored in -0 direction              
                MPI_Recv(tmp_pos_1_even, f1, MPI_DOUBLE, npr[3], 6, cart_comm, &status);// stored in +1 direction
                MPI_Recv(tmp_neg_1_even, f1, MPI_DOUBLE, npr[2], 7, cart_comm, &status);// stored in -1 direction
		
                // stop timing
		MPI_Barrier(MPI_COMM_WORLD);
                finish = MPI_Wtime();

                        // updating the exterior boundary points to the local lattice from temporary array 
                        // - 0 direction even (500-549)
		        for (int i = 0; i < f0/2; i++) {
        		        fi[i + volume].fi1 = tmp_neg_0_even[i].fi1; 
			        fi[i + volume].fi2 = tmp_neg_0_even[i].fi2; 
    		        }
		        // +0 direction even (550-599) 
		        for (int i = 0; i < f0/2; i++) {
                                fi[i + volume + f0/2].fi1 = tmp_pos_0_even[i].fi1; 
                                fi[i + volume + f0/2].fi2 = tmp_pos_0_even[i].fi2;
                        }
		        // - 1 direction even (600-649) 
                        for (int i = 0; i < f1/2; i++) {
                                fi[i + volume + f0].fi1 = tmp_neg_1_even[i].fi1;
                                fi[i + volume + f0].fi2 = tmp_neg_1_even[i].fi2;
                        }
                        // +1 direction even (650-699) 
                        for (int i = 0; i < f1/2; i++) {
                                fi[i+ volume+ f0 + f1/2].fi1 = tmp_pos_1_even[i].fi1;
                                fi[i+ volume+ f0 + f1/2].fi2 = tmp_pos_1_even[i].fi2;
                        }

		        //odd direction
		        // - 0 direction odd (700-749) 
                        for (int i = 0; i < f0/2; i++) {
                                fi[i + volume + bnd/2].fi1 = tmp_neg_0_odd[i].fi1;
                                fi[i + volume + bnd/2].fi2 = tmp_neg_0_odd[i].fi2;
                        }
                        // +0 direction odd (750-799) 
                        for (int i = 0; i < f0/2; i++) {
                                fi[i + volume + f0/2 + bnd/2].fi1 = tmp_pos_0_odd[i].fi1;
                                fi[i + volume + f0/2 + bnd/2].fi2 = tmp_pos_0_odd[i].fi2;
                        }
                        // - 1 direction odd (800-849) 
                        for (int i = 0; i < f1/2; i++) {
                                fi[i + volume + f0 + bnd/2].fi1 = tmp_neg_1_odd[i].fi1;
                                fi[i + volume + f0 + bnd/2].fi2 = tmp_neg_1_odd[i].fi2;
                        }
                        // +1 direction odd (850-899) 
                        for (int i = 0; i < f1/2; i++) {
                                fi[i+ volume+ f0 + f1/2 + bnd/2].fi1 = tmp_pos_1_odd[i].fi1;
                                fi[i+ volume+ f0 + f1/2 + bnd/2].fi2 = tmp_pos_1_odd[i].fi2;
                        }
                

                // Communication time taken by each processor
                MPI_Barrier(MPI_COMM_WORLD);
                for(int i = 0; i < ((nPROC0*nPROC1) - 1); i++){
                        if(my_rank == i){
                                printf("\t\t\t\t\tCommunication Time taken by Processor %d = %e milliseconds \n", my_rank, finish -start);
                        }
                }

        }

}



int main(int argc, char* argv[]) {

        int         my_rank;       /* rank of process      */
        int         tag = 0;       /* tag for messages     */
        int	    l0, l1, l2;
	FILE*	fp;
	char fname[128] = "input.txt";

	int nPROC0;
	int nPROC1;
	int f0,f1,bnd;
	int p;

	//routines
	int * iptnl;
	/* Start up MPI */
	MPI_Status  status;        /* return status for    */
       	// MPI_Comm cart_comm;                           /* receive              */
        MPI_Init(&argc, &argv);
        MPI_Comm_rank(MPI_COMM_WORLD, &my_rank); // Find out process rank
        MPI_Comm_size(MPI_COMM_WORLD, &p); // Find out number of processes

	// read in NPROC0 and NPROC1
        fp = fopen(fname, "r");
        fscanf(fp, "%i\n", &nPROC0);
        fscanf(fp, "%i\n", &nPROC1);
	// read in lattice size
        fscanf(fp, "%i\n", &l0);
        fscanf(fp, "%i\n", &l1);
        fscanf(fp, "%i\n", &l2);

	// we consider l0 and l1 as local and l2 as global
	int local_l0 = l0/nPROC0;
        int local_l1 = l1/nPROC1;

	int dimensions[2] = {nPROC0, nPROC1}; /* assuming p = 4 */
        int wrap_around[2];
        int coordinates[2];
        int cpr[2];
        int npr[4];
        //int nrows, ncols;
        int source;        /* rank of left or top neighbour in MPIShift */
        int dest;          /* rank of right or bottom neighbour  */
        int my_cart_rank;
        MPI_Comm cart_comm, row_comm, col_comm; // comunicators

        /* set up global grid information */

        /* circurlar shft in second dimension, also in first just because */
        wrap_around[0] = 1;
        wrap_around[1] = 1;

        // create grid
        MPI_Cart_create(MPI_COMM_WORLD, 2, dimensions, wrap_around, 1, &cart_comm);
        MPI_Comm_rank(cart_comm, &my_cart_rank);

        /* get process coordinates in grid communicator */
        MPI_Cart_coords(cart_comm, my_cart_rank, 2, coordinates);

        /* set up cartesian coordinates for communication */
        cpr[0] = coordinates[1];
        cpr[1] = coordinates[0];
        //printf("Processor rank = %2d \n cpr[0] = %d, cpr[1] = %d\n", my_cart_rank, cpr[0], cpr[1]);

        /* Shift the communicator to find the neighboring processes */
        int displ =  1;    /* shift by  1 */
        int index =  1;    /* shift along the 1st index (out of 2) */
        MPI_Cart_shift(cart_comm, index, displ, &source, &dest);
        npr[0] = source;
        npr[1] = dest;
        //printf("Rank %d: npr[0] = %d, npr[1] = %d\n", my_cart_rank, npr[0], npr[1]);
        index = 0;
        MPI_Cart_shift(cart_comm, index, displ, &source, &dest);
        npr[2] = source;
        npr[3] = dest;
        //printf("Rank %d: npr[2] = %d, npr[3] = %d\n", my_cart_rank, npr[2], npr[3]);


        //local_lattice(l0, l1, l2);
        f0 = face0(local_l0,local_l1,l2,nPROC0);
        f1 =  face1(local_l0,local_l1,l2,nPROC1);
        bnd = bndry(f0,f1);
	int volume = local_l0*local_l1*l2;

        if ((nPROC0 == 1) || (nPROC1 == 1)) {
        	printf("Mu is not divided, please enter higher dimension for processor");
        	MPI_Abort(MPI_COMM_WORLD, 1);
        }
	//printf("Processor rank = %2d \n cpr[0] = %d, cpr[1] = %d\n", my_rank, cpr[0], cpr[1]);
	//routines
	iptnl = ipt(local_l0,local_l1, l2); //lexicographic index
        int ** iupnl = iup(local_l0,local_l1, l2, f0, f1, bnd, iptnl);
       	int ** idnnl = idn(local_l0,local_l1, l2, f0, f1, bnd, iptnl);
       	int * imap = map(bnd, iupnl, idnnl, local_l0, local_l1, l2, iptnl);

        if(my_rank == 0)
        {
                printf("User input nPROC0, nPROC1: %2d, %2d\n", nPROC0, nPROC1);
                printf("and Global lattice size:L0 = %2d, L1 = %2d, L2 = %2d\n",l0,l1,l2);
                printf("face0 = %d \n",f0);
                printf("face1 = %d \n",f1);
                printf("bndry = %d \n",bnd);
        }
        
        // initialize the 'field' with random values with the given ordering
	struct field * fi = (struct field * )malloc(sizeof(struct field)*(volume + bnd));
	srand(time(0));

         if(((l0*l1) - 1) % 2 == 0){
                        //Even points of local lattice
		        for (int i = 0; i < volume/2; i++){
                                 if((iptnl[i] % 2 == 0) || (iptnl[i] == 0 )){
			                fi[i].fi1 = abs((double) rand());
			                fi[i].fi2 = abs((double) rand());
			                //printf("no =%d, f1[%2d] = %d, f2[%2d] = %d\n", i ,i, iptnl[i], i, iptnl[i]);
                                }
                        }

                        //Odd points of local lattice
                        for (int i = volume/2; i < volume; i++){
                                if((iptnl[i] % 2 != 0)){
                                        fi[i].fi1 = abs((double) rand());
			                fi[i].fi2 = abs((double) rand());
                                        //printf("no =%d, f1[%2d] = %lf, f2[%2d] = %lf\n", k ,iptnl[k],iptnl[k],iptnl[k], fi[k].fi1, fi[k].fi2);
                                        //printf("no =%d, f1[%2d] = %d, f2[%2d] = %d\n", i ,i, iptnl[i], i, iptnl[i]);
                                }
                        }
         }else{
                        //Even points of local lattice
		        for (int i = 0; i < volume/2; i++){
			                fi[i].fi1 = abs((double) rand());
			                fi[i].fi2 = abs((double) rand());
			                //printf("no =%d, f1[%2d] = %d, f2[%2d] = %d\n", i ,i, iptnl[i], i, iptnl[i]);    
                        }

                        //Odd points of local lattice
                        for (int i = volume/2; i < volume; i++){
                                        fi[i].fi1 = abs((double) rand());
			                fi[i].fi2 = abs((double) rand());
                                        //printf("no =%d, f1[%2d] = %d, f2[%2d] = %d\n", i ,i, iptnl[i], i, iptnl[i]);
                        }
                }


         
		// Exterior Boundary points of local lattice
		//Even Points
		// -ve 0 500 to 549
		for (int j = 0 ; j < volume/2 ; j++) {
                        if (((iptnl[j] % local_l0 ) == 0 ) || (iptnl[j] == 0)) {
                                fi[idnnl[j][0]].fi1 = abs((double) rand());
                                fi[idnnl[j][0]].fi2 = abs((double) rand());
				
                               // printf("no =%d, f1[%2d] = %lf, f2[%2d] = %lf\n", j, idnnl[j][0], idnnl[j][0], fi[j].fi1, fi[j].fi2);

                        }
                }

		// +ve 0 550 to 599
		for (int j = 0 ; j < volume/2 ; j++) {
                        if ((((iptnl[j] + 1) % local_l0 ) == 0) && (iptnl[j] != 0)) {
                                fi[iupnl[j][0]].fi1 = abs((double) rand());
                                fi[iupnl[j][0]].fi2 = abs((double) rand());
                                //printf("no =%d, f1[%2d] = %lf, f2[%2d] = %lf\n", j, iupnl[j][0], iupnl[j][0], fi[j].fi1, fi[j].fi2);

                        }
                }

		// -ve 1 600 to 649
		int z=0;
		for (int j = 0 ; j < volume/2 ; j++) {
                        if( (iptnl[j] >= local_l0*local_l1*z) && (iptnl[j] < (local_l0 + local_l0*local_l1*z) )) {
                                fi[idnnl[j][1]].fi1 = abs((double) rand());
                                fi[idnnl[j][1]].fi2 = abs((double) rand());
                               // printf("no =%d, f1[%2d] = %lf, f2[%2d] = %lf\n", j, idnnl[j][1], idnnl[j][1], fi[j].fi1, fi[j].fi2);
                                        if (iptnl[j] >= (local_l0*local_l1*z + local_l0) - 2){
                                                 z++;
                                        }
                        }
                }

		// +ve 1  650 to 699
		z = 0;
		for (int j = 0 ; j < volume/2 ; j++) {
                        if ((iptnl[j] > (local_l0*local_l1 - 1) - local_l0 + local_l0*local_l1*z ) && (iptnl[j] <= (local_l0*local_l1) + local_l0*local_l1*z)) {
                                fi[iupnl[j][1]].fi1 = abs((double) rand());
                                fi[iupnl[j][1]].fi2 = abs((double) rand());
                               // printf("no =%d, f1[%2d] = %lf, f2[%2d] = %lf\n", j, iupnl[j][1], iupnl[j][1], fi[j].fi1, fi[j].fi2);
                                        if (iptnl[j] >= (local_l0*local_l1) + local_l0*local_l1*z - 2){
			                                	z++;
		                            	}
                        }
                }


		//Odd Points
		// -ve 0 700 to 749
		for (int j = volume/2 ; j < volume ; j++) {
                        if ((iptnl[j] % local_l0 ) == 0) {
                                fi[idnnl[j][0]].fi1 = abs((double) rand());
                                fi[idnnl[j][0]].fi2 = abs((double) rand());
                                //printf("no =%d, f1[%2d] = %lf, f2[%2d] = %lf\n", j, idnnl[j][0], idnnl[j][0], fi[j].fi1, fi[j].fi2);

                        }
                }

		// +ve 0 750 to 799
		for (int j = volume/2 ; j < volume ; j++) {
                       if (((iptnl[j] + 1) % local_l0) == 0){
                                fi[iupnl[j][0]].fi1 = abs((double) rand());
                                fi[iupnl[j][0]].fi2 = abs((double) rand());
                                //printf("no =%d, f1[%2d] = %lf, f2[%2d] = %lf\n", j, iupnl[j][0], iupnl[j][0], fi[j].fi1, fi[j].fi2);

                        }
                }

		// -ve 1 800 to 849
		z=0;
		for (int j = volume/2 ; j < volume ; j++) {
                        if((iptnl[j] >= local_l0*local_l1*z) && (iptnl[j] < (local_l0 + local_l0*local_l1*z))) {
                                fi[idnnl[j][1]].fi1 =  abs((double) rand());
                                fi[idnnl[j][1]].fi2 =  abs((double) rand());
                                //printf("no =%d, f1[%2d] = %lf, f2[%2d] = %lf\n", j, idnnl[j][1], idnnl[j][1], fi[j].fi1, fi[j].fi2);
                                    if (iptnl[j] >= (local_l0*local_l1*z + local_l0) - 2){
                                             z++;
                                     }
                        }
                }

		// +ve 1  850 to 899
		z = 0;
		for (int j = volume/2 ; j < volume ; j++) {
                       if((iptnl[j] > (local_l0*local_l1 - 1) - local_l0 + local_l0*local_l1*z) && (iptnl[j] <= (local_l0*local_l1) + local_l0*local_l1*z)) {
                                fi[iupnl[j][1]].fi1 = abs((double) rand());
                                fi[iupnl[j][1]].fi2 = abs((double) rand());
                                //printf("no =%d, f1[%2d] = %lf, f2[%2d] = %lf\n", j, iupnl[j][1], iupnl[j][1], fi[j].fi1, fi[j].fi2);
                                        if (iptnl[j] >= (local_l0*local_l1) + local_l0*local_l1*z - 2){
                                             z++;
                                         }
                        }
               }



		if(my_rank == 3){
			//printf("\t\tEach value of every point on the local lattice + boundaries with two components (fi1 and fi2) are stored as real and double. Then the calculated communication time gets printed.\n\n");
			for(int h = 0; h < volume + bnd; h++) {
						//printf("\t\t\tno= %d, fi[%d]f1 = %lf, fi[%d]f2 = %lf\n",h, h, fi[h].fi1, h, fi[h].fi2);
			}
		}



                // check for a random processor if the exterior boundary points were update by the correct neighboring processors
                int output_rank = rand() % (nPROC0*nPROC1 - 1);

                MPI_Barrier(MPI_COMM_WORLD);
        
                if(my_rank == output_rank) {
			printf("\t\tProcessor %d exterior boundary values for - 0 (even) direction before \n\n",my_rank, npr[0]);
			for( int i = volume; i < volume+f0/2; i++) {
				printf("\t\t\tExterior boundary (%d) fi.1 = %f, fi.2 = %f \n", i, fi[i].fi1, fi[i].fi2);
				}
			printf("\n\t\tProcessor %d exterior boundary values for + 0 (even) direction before\n\n",my_rank, npr[1]);
			for( int i = volume+f0/2; i < volume+f0; i++) {
				printf("\t\t\tExterior boundary (%d) fi.1 = %f, fi.2 = %f \n", i, fi[i].fi1, fi[i].fi2);
                                }
			printf("\n\t\tProcessor %d exterior boundary values for - 1 (even) direction before \n\n",my_rank, npr[2]);
                        for( int i = volume+f0; i < volume+f0+f1/2; i++) {
                                printf("\t\t\tExterior boundary (%d) fi.1 = %f, fi.2 = %f \n", i, fi[i].fi1, fi[i].fi2);
                                }
			printf("\n\t\tProcessor %d exterior boundary values for + 1 (even) direction before \n\n",my_rank, npr[3]);
                        for( int i = volume+f0+f1/2; i < volume+f0+f1; i++) {
                                printf("\t\t\tExterior boundary (%d) fi.1 = %f, fi.2 = %f \n", i, fi[i].fi1, fi[i].fi2);
                                }

			// Odd direction
			printf("\n\t\tProcessor %d exterior boundary values for - 0 (odd) direction before  \n\n",my_rank, npr[0]);
                        for( int i = volume+bnd/2; i <volume+bnd/2+ f0/2; i++) {
                                printf("\t\t\tExterior boundary (%d) fi.1 = %f, fi.2 = %f \n", i, fi[i].fi1, fi[i].fi2);
                                }
                        printf("\n\t\tProcessor %d exterior boundary values for + 0 (odd) direction before\n\n",my_rank, npr[1]);
                        for( int i = volume+f0/2+bnd/2; i < volume+f0+bnd/2; i++) {
                                printf("\t\t\tExterior boundary (%d) fi.1 = %f, fi.2 = %f \n", i, fi[i].fi1, fi[i].fi2);
                                }
                        printf("\n\t\tProcessor %d exterior boundary values for - 1 (odd) direction before \n\n",my_rank, npr[2]);
                        for( int i = volume+f0+bnd/2; i < volume+f0+f1/2+bnd/2; i++) {
                                printf("\t\t\tExterior boundary (%d) fi.1 = %f, fi.2 = %f \n", i, fi[i].fi1, fi[i].fi2);
                                }
                        printf("\n\t\tProcessor %d exterior boundary values for + 1 (odd) direction before \n\n",my_rank, npr[3]);
                         for( int i = volume+f0+f1/2+bnd/2; i < volume+f0+f1+bnd/2; i++) {
                                printf("\t\t\tExterior boundary (%d) fi.1 = %f, fi.2 = %f \n", i, fi[i].fi1, fi[i].fi2);
                                }

                        printf("\n\n");			

			}


   
              
                MPI_Barrier(MPI_COMM_WORLD);
		// communication for the boundary points
                sendfunc(fi, npr, iptnl, imap, iupnl, idnnl, f0, f1, local_l0, local_l1, l2, bnd, my_rank, cart_comm, status,nPROC0,nPROC1); 


                MPI_Barrier(MPI_COMM_WORLD);
                if(my_rank == output_rank) {
			printf("\n\n\t\tProcessor %d received exterior boundary values for - 0 (even) direction from processor %d \n\n",my_rank, npr[0]);
			for( int i = volume; i < volume+f0/2; i++) {
				printf("\t\t\tExterior boundary (%d) fi.1 = %f, fi.2 = %f \n", i, fi[i].fi1, fi[i].fi2);
				}
			printf("\n\t\tProcessor %d received exterior boundary values for + 0 (even) direction from processor %d \n\n",my_rank, npr[1]);
			for( int i = volume+f0/2; i < volume+f0; i++) {
				printf("\t\t\tExterior boundary (%d) fi.1 = %f, fi.2 = %f \n", i, fi[i].fi1, fi[i].fi2);
                                }
			printf("\n\t\tProcessor %d received exterior boundary values for - 1 (even) direction from processor %d \n\n",my_rank, npr[2]);
                        for( int i = volume+f0; i < volume+f0+f1/2; i++) {
                                printf("\t\t\tExterior boundary (%d) fi.1 = %f, fi.2 = %f \n", i, fi[i].fi1, fi[i].fi2);
                                }
			printf("\n\t\tProcessor %d received exterior boundary values for + 1 (even) direction from processor %d \n\n",my_rank, npr[3]);
                        for( int i = volume+f0+f1/2; i < volume+f0+f1; i++) {
                                printf("\t\t\tExterior boundary (%d) fi.1 = %f, fi.2 = %f \n", i, fi[i].fi1, fi[i].fi2);
                                }

			// Odd direction
			printf("\n\t\tProcessor %d received exterior boundary values for - 0 (odd) direction from processor %d \n\n",my_rank, npr[0]);
                        for( int i = volume+bnd/2; i <volume+bnd/2+ f0/2; i++) {
                                printf("\t\t\tExterior boundary (%d) fi.1 = %f, fi.2 = %f \n", i, fi[i].fi1, fi[i].fi2);
                                }
                        printf("\n\t\tProcessor %d received exterior boundary values for + 0 (odd) direction from processor %d \n\n",my_rank, npr[1]);
                        for( int i = volume+f0/2+bnd/2; i < volume+f0+bnd/2; i++) {
                                printf("\t\t\tExterior boundary (%d) fi.1 = %f, fi.2 = %f \n", i, fi[i].fi1, fi[i].fi2);
                                }
                        printf("\n\t\tProcessor %d received exterior boundary values for - 1 (odd) direction from processor %d \n\n",my_rank, npr[2]);
                        for( int i = volume+f0+bnd/2; i < volume+f0+f1/2+bnd/2; i++) {
                                printf("\t\t\tExterior boundary (%d) fi.1 = %f, fi.2 = %f \n", i, fi[i].fi1, fi[i].fi2);
                                }
                        printf("\n\t\tProcessor %d received exterior boundary values for + 1 (odd) direction from processor %d \n\n",my_rank, npr[3]);
                         for( int i = volume+f0+f1/2+bnd/2; i < volume+f0+f1+bnd/2; i++) {
                                printf("\t\t\tExterior boundary (%d) fi.1 = %f, fi.2 = %f \n", i, fi[i].fi1, fi[i].fi2);
                                }			

			}


/* Shut down MPI */
    	MPI_Finalize();
	return 0;
}
