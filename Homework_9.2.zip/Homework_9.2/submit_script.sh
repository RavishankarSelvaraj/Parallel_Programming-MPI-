#!/bin/bash
#
#SBATCH --nodes=1
#SBATCH --ntasks=16
#SBATCH --exclusive
#SBATCH --partition=compute2011

module load mpi/openmpi
mpicc -lm project.c header.h header.c;
mpirun -np 16 ./a.out < input.txt
