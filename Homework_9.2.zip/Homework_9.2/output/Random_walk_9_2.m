% Exercise 9. 2 
% Random Walk
%
% Dominik Wirsig (2020067)
% Ravishankar Selvaraj (2036915)

Nmeas = 10000;          % number of random walks
T = 100;                % number of steps of random walk
dit_20 = zeros(Nmeas, T);    % matrix containing all measured distances
timefuncdist = zeros(1,T); % plot the function of t against t
Average_20 = zeros(1,T);   % plot the average against t
dit_Average20 = 0;

i = 0;
for i = 1 : T
       timefuncdist(i) = i;
end

% read in output file from the random walk on a lattice of global
% volume of 20 x 20 x 20
measurements20 = fopen('output_20.out', 'r');
for i = 1:Nmeas
    for j = 1:T
        dit_20(i,j) = fscanf(measurements20, '%f' , 1);
    end
end
fclose(measurements20);

% average
for i = 1:T
    for j = 1:Nmeas
        dit_Average20 = dit_Average20 + (dit_20(j, i))^2;
    end
    dit_Average20 = dit_Average20/Nmeas;
    Average_20(1, i) = dit_Average20;
    dit_Avergae20 = 0;
end

t = 1:1:100;

figure
grid on;
plot(Average_20, '*r');
title('Random walk on global volume 20 x 20 x 20 Lattice')
xlabel('Time (t)', 'FontSize',12)
ylabel('Distance', 'FontSize',12)
xlim([0 100])
ylim([0 100])
hold on
plot(timefuncdist, 'xg');
title('Random walk on global volume 20 x 20 x 20 Lattice')
legend('Average distance against t', 'Time function against t', 'Location', 'best')


Average_40 = zeros(1,T);   % plot the average against t
dit_Average40 = 0;

% read in output file from the random walk on a lattice of global
% volume of 40 x 40 x 40
measurements40 = fopen('output_40.out', 'r');
for i = 1:Nmeas
    for j = 1:T
        dit_40(i,j) = fscanf(measurements40, '%f' , 1);
    end
end
fclose(measurements40);


% average
for i = 1:T
    for j = 1:Nmeas
        dit_Average40 = dit_Average40 + (dit_40(j, i))^2;
    end
    dit_Average40 = dit_Average40/Nmeas;
    Average_40(1, i) = dit_Average40;
    dit_Average40 = 0;
end

figure
t = 1:1:100;
grid on;
plot(Average_40, '*b');
xlabel('Time (t)', 'FontSize',12)
ylabel('Distance', 'FontSize',12)
xlim([0 100])
ylim([0 100])
hold on
plot(timefuncdist, 'xg');
title('Random walk on global volume 40 x 40 x 40 Lattice')
legend('Average distance against t', 'Time function against t', 'Location', 'best')
