/*
 * Homework 9
 * Exercise 1 and 2
 * Lettice Setup and Random Walk
 * author: Ravishankar Selvaraj (2036915) Dominik Wirsig (2020067)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "header.h"
#include "mpi.h"


int main(int argc, char* argv[]) {

        int my_rank;       /* rank of process      */
        int p;             /* number of processes  */
        int l0, l1, l2;
        FILE*   fp;
	//FILE*   fx;

        char fname[128] = "input.txt";
        int nPROC0, nPROC1;
        int f0, f1, bnd;
	int x_global[3];
	int x_global_fixed[3];

        /* Start up MPI */
        MPI_Status  status;        /* return status for receive */
        MPI_Init(&argc, &argv);
        MPI_Comm_rank(MPI_COMM_WORLD, &my_rank); // Find out process rank
        MPI_Comm_size(MPI_COMM_WORLD, &p); // Find out number of processes

        // read in NPROC0 and NPROC1 from input file
        fp = fopen(fname, "r");
        fscanf(fp, "%i\n", &nPROC0);
        fscanf(fp, "%i\n", &nPROC1);

        // read in lattice size, we assume every 3 sizes as global
        fscanf(fp, "%i\n", &l0);
        fscanf(fp, "%i\n", &l1);
        fscanf(fp, "%i\n", &l2);

        // we consider l0 and l1 as local and l2 as global
        int local_l0 = l0/nPROC0;
        int local_l1 = l1/nPROC1;
        int volume = local_l0 * local_l1 * l2;

        //Count exterior boundary points of local lattice
        f0 = face0(local_l0,local_l1,l2,nPROC0);
        f1 =  face1(local_l0,local_l1,l2,nPROC1);
        bnd = bndry(f0,f1);

	// user inputs number of processes in 0 and 1 direction and the lattice sizes in 0, 1 and 2 direction
        if(my_rank == 0) {
                //printf("User input nPROC0, nPROC1: %2d, %2d\n", nPROC0, nPROC1);
                //printf("local lattice size of L0 = %2d, L1 = %2d, L2 = %2d\n", l0, l1, l2);
                //printf("face0 = %d \n", f0);
                //printf("face1 = %d \n", f1);
                //printf("bndry = %d \n", bnd);
        }

	if ((nPROC0 == 1) || (nPROC1 == 1))
        {
                printf("Mu is not divided, please enter higher dimension for processor");
                MPI_Abort(MPI_COMM_WORLD, 1);
        }

	// create cartesian grid of processors (size nPORC0*nPROC1)
        int dimensions[2] = {nPROC0, nPROC1}; // assuming p = 4
        int wrap_around[2];
        int coordinates[2];
        int cpr[2];
        int npr[4];
        int source;        // rank of left or top neighbour in MPIShift
        int dest;          // rank of right or bottom neighbour
        int my_cart_rank;

        MPI_Comm cart_comm; // comunicator

        // set up global grid information for cpr and npr
        // circurlar shft in second dimension, also in first just because
        wrap_around[0] = 1;
        wrap_around[1] = 1;

        // create grid
        MPI_Cart_create(MPI_COMM_WORLD, 2, dimensions, wrap_around, 1, &cart_comm);
        MPI_Comm_rank(cart_comm, &my_cart_rank);

        // get process coordinates in grid communicator
        MPI_Cart_coords(cart_comm, my_cart_rank, 2, coordinates);

        // set up cartesian coordinates for communication
        cpr[0] = coordinates[1];
        cpr[1] = coordinates[0];
        //printf("Processor rank = %2d \n cpr[0] = %d, cpr[1] = %d\n", my_cart_rank, cpr[0], cpr[1]);

        // Shift the communicator to find the neighboring processes
        int displ =  1;    // shift by  1
        int index =  1;    // shift along the 1st index (out of 2)
        MPI_Cart_shift(cart_comm, index, displ, &source, &dest);
        npr[0] = source;
        npr[1] = dest;
        //printf("Rank %d: npr[0] = %d, npr[1] = %d\n", my_cart_rank, npr[0], npr[1]);
        index = 0;
        MPI_Cart_shift(cart_comm, index, displ, &source, &dest);
        npr[2] = source;
        npr[3] = dest;
        //printf("Rank %d: npr[2] = %d, npr[3] = %d\n", my_cart_rank, npr[2], npr[3]);
	//printf("Processor rank = %2d \n cpr[0] = %d, cpr[1] = %d\n", my_cart_rank, cpr[0], cpr[1]);

	// create a two dimensional array of size [nPROC0*nPROC1] [2] to store all cpr[2] values
	// from all processors as a "lookup"-table. This table has all the information of the indices
	// of each processors
	int** global_cpr = (int**)malloc(sizeof(int*)*(nPROC0*nPROC1));
	for (int f = 0; f < (nPROC0*nPROC1); f++) {
                global_cpr[f] = (int*)malloc(sizeof(int) * 2);
        }

	// each processor broadcasts its cpr coordinates to the other processes
	for (int d = 0; d < nPROC0*nPROC1; d ++){
		if( my_cart_rank == d){
			global_cpr[d][0] = cpr[0];
			global_cpr[d][1] = cpr[1];
		//	printf("rank =%d, cpr[0] = %d, cpr[1] = %d\n",my_cart_rank, cpr[0], cpr[1]); 
		}
		MPI_Bcast(&global_cpr[d][0], 1, MPI_INT, d, MPI_COMM_WORLD);
		MPI_Bcast(&global_cpr[d][1], 1, MPI_INT, d, MPI_COMM_WORLD);
	}

	// create a two dimensional array of size [nPROC0*nPROC1] [4] to store all npr[4] values
        // from all processors as a "lookup"-table. This table has all the information of the neigboring
        // in each direction of the processors
  	int** global_npr = (int**)malloc(sizeof(int*)*(nPROC0*nPROC1));
        for (int g = 0; g < (nPROC0*nPROC1); g++) {
                global_npr[g] = (int*)malloc(sizeof(int) * 4);
        }

        for (int d = 0; d < nPROC0*nPROC1; d ++){
                if( my_cart_rank == d){
                        global_npr[d][0] = npr[0];
                        global_npr[d][1] = npr[1];
			global_npr[d][2] = npr[2];
                        global_npr[d][3] = npr[3];
                //      printf("rank =%d, cpr[0] = %d, cpr[1] = %d\n",my_cart_rank, cpr[0], cpr[1]);
                }
                MPI_Bcast(&global_cpr[d][0], 1, MPI_INT, d, MPI_COMM_WORLD);
                MPI_Bcast(&global_cpr[d][1], 1, MPI_INT, d, MPI_COMM_WORLD);
		MPI_Bcast(&global_npr[d][0], 1, MPI_INT, d, MPI_COMM_WORLD);
		MPI_Bcast(&global_npr[d][1], 1, MPI_INT, d, MPI_COMM_WORLD);
		MPI_Bcast(&global_npr[d][2], 1, MPI_INT, d, MPI_COMM_WORLD);
		MPI_Bcast(&global_npr[d][3], 1, MPI_INT, d, MPI_COMM_WORLD);
        }

	//routine to create arrays for indicess

        // lexicographic index
        int * iptnl = ipt(local_l0,local_l1, l2);
	// nearest neigbors in "up" direction
        int ** iupnl = iup(local_l0,local_l1, l2, f0, f1, bnd, iptnl);
	// nearest neighbors in "down" direction
        int ** idnnl = idn(local_l0,local_l1, l2, f0, f1, bnd, iptnl);
	// index of the point on the local lattice of the neighboring process
        int * imap = map(bnd, iupnl, idnnl, local_l0, local_l1, l2, iptnl);


        if(my_rank == 0) {
/*                iptnl = ipt(local_l0,local_l1, l2);
                int ** iupnl = iup(local_l0,local_l1, l2, f0, f1, bnd, iptnl);
                int ** idnnl = idn(local_l0,local_l1, l2, f0, f1, bnd, iptnl);
                int * imap = map(bnd, iupnl, idnnl, local_l0, local_l1, l2, iptnl);
		fx = fopen("output_map.txt", "w+");
		fprintf(fx,"User input nPROC0, nPROC1: %2d, %2d\n", nPROC0, nPROC1);
                fprintf(fx,"local lattice size of L0 = %2d, L1 = %2d, L2 = %2d\n", l0, l1, l2);
                fprintf(fx,"face0 = %d \n", f0);
                fprintf(fx,"face1 = %d \n", f1);
                fprintf(fx,"bndry = %d \n", bnd);
		fprintf(fx,"map[BNDRY] stores the index of the boundary points of the neighboring local lattice.\n\n");
		for (int u = 0; u < bnd; u++)
*/                for (int u = 0; u < bnd; u++) {
                        //printf("ipt[%2d] = %d\n", u, iptnl[u]);
                        //printf("iup[%2d][0] = %d\n", u, iupnl[u][0]);
                        //printf("iup[%2d][1] = %d\n", u, iupnl[u][1]);
			//printf("rank: %d, cpr[0] = %d, cpr[1] = %d\n", u, global_cpr[u][0], global_cpr[u][1]);
                        //printf("idn[%2d][0] = %d\n", u, idnnl[u][0]);
                        //printf("idn[%2d][1] = %d\n", u, idnnl[u][1]);
                        //printf("map[%2d] = %d\n", u, imap[u]);
                        //fprintf(fx, "map[%2d] = %d\n", u, imap[u]);
                	//fprintf(fx, "idn[%2d][0] = %d,\t idn[%2d][1] = %d\n", u, idnnl[u][0], u, idnnl[u][1]);
			//fprintf(fx, "iup[%2d][1] = %d\n", u, iupnl[u][1]);
		}
			//fclose(fx);
		//for (int u = 0; u < nPROC0*nPROC1; u ++){
		//	printf("rank: %d, npr[0] = %d, npr[1] = %d,  npr[2] = %d, npr[3] = %d\n", u, global_npr[u][0], global_npr[u][1], global_npr[u][2], global_npr[u][3]);
		//}

	}


	// 9.2 RANDOM WALK

        int Nmeas = pow(10,4);
        int T = 100;
	int neighbour_rank;
        srand(time(0));
        int limit_x0 = local_l0 - 1;
        int limit_x1 = local_l1 - 1;
        int limit_x2 = l2 - 1;
	int x_0;
	int x_1;
	int x_2;
        int working_rank;

	for(int z = 1; z <= Nmeas ; z++){

		// starting point is chosen from a random processor
                if(my_rank == 0) { working_rank = rand() % (nPROC0*nPROC1 - 1); }
                MPI_Bcast(&working_rank, 1, MPI_INT, 0, MPI_COMM_WORLD);
                MPI_Barrier(MPI_COMM_WORLD);

		if(my_rank == working_rank){

			// starting point is chosen at random
			x_0 = rand() % limit_x0;
			x_1 = rand() % limit_x1;
			x_2 = rand() % limit_x2;
			x_global[0] = cpr[0]*local_l0 + x_0;
                        x_global[1] = cpr[1]*local_l1 + x_1;
                        x_global[2] = x_2;
			//printf("no = %d, guessed rank: %d : x[0] = %2d, x1 = %2d, x2 = %2d\n", z, my_rank, x_0, x_1, x_2);
			//printf("x0_global = %2d, x1_global = %2d, x2_global = %2d, guessed rank: %d\n", x_global[0], x_global[1], x_global[2], my_rank);

			neighbour_rank = working_rank;
                        x_global_fixed[0] = x_global[0];
			x_global_fixed[1] = x_global[1];
			x_global_fixed[2] = x_global[2];

                	for(int t=1; t <= 100; t++){

                                // move one step in a random direction on the lattice
				int * x_new = move_point(x_global, iupnl, idnnl, iptnl, imap, global_cpr, global_npr, neighbour_rank, local_l0, local_l1, l2);
				//printf("x0 = %d, x1 = %d, x2 = %d, rank after moving = %d\n\n", x_new[0], x_new[1], x_new[2], x_new[3]);
				neighbour_rank = x_new[3];
				x_global[0] = global_cpr[x_new[3]][0]*local_l0 + x_new[0];
                                x_global[1] = global_cpr[x_new[3]][1]*local_l1 + x_new[1];
                                x_global[2] = x_new[2];
				//printf("x0 = %d, x1 = %d, x2 = %d, rank after moving = %d\n", x_global[0], x_global[1], x_global[2], x_new[3]);

				double m = measure(x_global_fixed[0], x_global_fixed[1], x_global_fixed[2], x_global[0], x_global[1], x_global[2], nPROC0, nPROC1, local_l0, local_l1, l2);
				printf( "%f\n", m);
        
                        }
		}
	}

        /* Shut down MPI */
        MPI_Finalize();
        return 0;
}
